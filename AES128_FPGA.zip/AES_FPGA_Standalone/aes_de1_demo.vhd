-- DE1 standalone public-test-key demo. No UART, no external peripherals.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity aes_de1_demo is
    port(CLOCK_50 : in std_logic;
         KEY : in std_logic_vector(1 downto 0);
         SW : in std_logic_vector(7 downto 0);
         LEDG : out std_logic_vector(1 downto 0);
         HEX0, HEX1, HEX2, HEX3 : out std_logic_vector(6 downto 0));
end entity;
architecture rtl of aes_de1_demo is
    type bank_t is array(0 to 10) of std_logic_vector(127 downto 0);
    signal bank : bank_t := (others => (others => '0'));
    signal reset_meta, reset_sync : std_logic := '0';
    signal button_meta, button_sync, button_prev : std_logic := '1';
    signal sw_meta, sw_sync : std_logic_vector(7 downto 0) := (others => '0');
    signal rst, start_pulse : std_logic;
    signal key_data, rk : std_logic_vector(127 downto 0);
    signal idx : std_logic_vector(3 downto 0);
    signal valid, done, busy : std_logic;
    signal ready : std_logic := '0';
    signal page : std_logic_vector(15 downto 0);
    function seg(n : std_logic_vector(3 downto 0)) return std_logic_vector is
    begin -- active low, vector order gfedcba
        case n is
            when x"0" => return "1000000"; when x"1" => return "1111001";
            when x"2" => return "0100100"; when x"3" => return "0110000";
            when x"4" => return "0011001"; when x"5" => return "0010010";
            when x"6" => return "0000010"; when x"7" => return "1111000";
            when x"8" => return "0000000"; when x"9" => return "0010000";
            when x"A" => return "0001000"; when x"B" => return "0000011";
            when x"C" => return "1000110"; when x"D" => return "0100001";
            when x"E" => return "0000110"; when x"F" => return "0001110";
            when others => return "1111111";
        end case;
    end function;
begin
    process(CLOCK_50)
    begin
        if rising_edge(CLOCK_50) then
            reset_meta <= KEY(0); reset_sync <= reset_meta;
            button_meta <= KEY(1); button_sync <= button_meta;
            button_prev <= button_sync;
            sw_meta <= SW; sw_sync <= sw_meta;
        end if;
    end process;
    rst <= not reset_sync;
    start_pulse <= button_prev and not button_sync and not rst and not busy;
    key_data <= x"2B7E151628AED2A6ABF7158809CF4F3C" when sw_sync(7)='0' else
                x"000102030405060708090A0B0C0D0E0F";
    core : entity work.aes128_keyexp port map(
        clk=>CLOCK_50, rst=>rst, start=>start_pulse, key_in=>key_data,
        round_key=>rk, round_index=>idx, valid=>valid, done=>done, busy=>busy);
    process(CLOCK_50)
    begin
        if rising_edge(CLOCK_50) then
            if rst='1' then
                bank <= (others => (others => '0')); ready <= '0';
            else
                if valid='1' then bank(to_integer(unsigned(idx))) <= rk; end if;
                if start_pulse='1' then ready<='0';
                elsif done='1' then ready<='1'; end if;
            end if;
        end if;
    end process;
    process(sw_sync, bank, ready)
        variable r, j : natural;
    begin
        page <= (others=>'0');
        r := to_integer(unsigned(sw_sync(6 downto 3)));
        j := to_integer(unsigned(sw_sync(2 downto 0)));
        if ready='1' and r<=10 then page <= bank(r)(127-16*j downto 112-16*j); end if;
    end process;
    HEX3 <= seg(page(15 downto 12)) when ready='1' else "1111111";
    HEX2 <= seg(page(11 downto 8)) when ready='1' else "1111111";
    HEX1 <= seg(page(7 downto 4)) when ready='1' else "1111111";
    HEX0 <= seg(page(3 downto 0)) when ready='1' else "1111111";
    LEDG(0) <= ready; LEDG(1)<=busy;
end architecture;
