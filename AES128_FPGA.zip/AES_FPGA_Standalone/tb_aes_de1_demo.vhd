library ieee;
use ieee.std_logic_1164.all;
entity tb_aes_de1_demo is end;
architecture sim of tb_aes_de1_demo is
    signal clk : std_logic := '0'; signal keys : std_logic_vector(1 downto 0):="10";
    signal sw : std_logic_vector(7 downto 0):=(others=>'0');
    signal led : std_logic_vector(1 downto 0);
    signal h0,h1,h2,h3 : std_logic_vector(6 downto 0);
    signal finished : boolean := false;
begin
    clk <= not clk after 10 ns when not finished else '0';
    dut: entity work.aes_de1_demo port map(clk,keys,sw,led,h0,h1,h2,h3);
    process
    begin
        wait for 100 ns; keys <= "11"; wait for 100 ns;
        keys <= "01"; wait for 100 ns; keys <= "11";
        wait for 500 ns;
        assert led(0)='1' report "DONE LED missing" severity failure;
        -- K0 page0 = 2B7E
        assert h3="0100100" and h2="0000011" and h1="1111000" and h0="0000110" report "K0 display mismatch" severity failure;
        sw <= x"08"; wait for 100 ns; -- K1 page0 = A0FA
        assert h3="0001000" and h2="1000000" and h1="0001110" and h0="0001000" report "K1 display mismatch" severity failure;
        sw <= x"57"; wait for 100 ns; -- K10 page7 = 0CA6
        assert h3="1000000" and h2="1000110" and h1="0001000" and h0="0000010" report "K10 display mismatch" severity failure;
        sw <= x"80"; wait for 100 ns; keys <= "01"; wait for 100 ns; keys <= "11"; wait for 500 ns;
        assert h3="1000000" and h2="1000000" and h1="1000000" and h0="1111001" report "Second key display mismatch" severity failure;
        report "PASS: DE1 display and key selection" severity note; finished <= true; wait;
    end process;
end architecture;
