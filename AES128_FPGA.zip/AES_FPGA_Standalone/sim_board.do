if {![file isdirectory work]} {vlib work}
vcom -93 aes128_keyexp_pkg.vhd
vcom -93 aes128_keyexp.vhd
vcom -93 aes_de1_demo.vhd
vcom -93 tb_aes_de1_demo.vhd
vsim work.tb_aes_de1_demo
add wave -r sim:/tb_aes_de1_demo/*
run -all
wave zoom full
