-- AES-128 Key Expansion: mathematical S-Box support (FIPS 197).
-- Synthesizable VHDL. No 256-entry lookup table is used.
-- This implementation is UNMASKED; it does not claim side-channel protection.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

package aes128_keyexp_pkg is
    subtype byte_t is std_logic_vector(7 downto 0);
    subtype word_t is std_logic_vector(31 downto 0);

    function aes_sbox(x : byte_t) return byte_t;
    function aes_subword(w : word_t) return word_t;
    function aes_rotword(w : word_t) return word_t;
    function aes_xtime(x : byte_t) return byte_t;
end package aes128_keyexp_pkg;

package body aes128_keyexp_pkg is

    -- Multiplication in GF(2^8), reduced modulo x^8+x^4+x^3+x+1.
    function gf_mul(a : byte_t; b : byte_t) return byte_t is
        variable aa : byte_t := a;
        variable bb : byte_t := b;
        variable p  : byte_t := (others => '0');
    begin
        for i in 0 to 7 loop
            if bb(0) = '1' then
                p := p xor aa;
            end if;
            if aa(7) = '1' then
                aa := (aa(6 downto 0) & '0') xor x"1B";
            else
                aa := aa(6 downto 0) & '0';
            end if;
            bb := '0' & bb(7 downto 1);
        end loop;
        return p;
    end function;

    -- Dedicated squaring circuit: linear XOR equations in GF(2^8).
    -- This is cheaper in principle than a general-purpose GF multiplier.
    function gf_square(a : byte_t) return byte_t is
        variable z : byte_t;
    begin
        z(0) := a(0) xor a(4) xor a(6);
        z(1) := a(4) xor a(6) xor a(7);
        z(2) := a(1) xor a(5);
        z(3) := a(4) xor a(5) xor a(6) xor a(7);
        z(4) := a(2) xor a(4) xor a(7);
        z(5) := a(5) xor a(6);
        z(6) := a(3) xor a(5);
        z(7) := a(6) xor a(7);
        return z;
    end function;

    -- Inversion by a^(254), using a fixed addition chain.
    -- 0 maps to 0, as required for AES S-Box construction.
    function gf_inverse(a : byte_t) return byte_t is
        variable a2, a3, a6, a7, a14, a15 : byte_t;
        variable a30, a60, a120, a127     : byte_t;
    begin
        a2   := gf_square(a);
        a3   := gf_mul(a2, a);
        a6   := gf_square(a3);
        a7   := gf_mul(a6, a);
        a14  := gf_square(a7);
        a15  := gf_mul(a14, a);
        a30  := gf_square(a15);
        a60  := gf_square(a30);
        a120 := gf_square(a60);
        a127 := gf_mul(a120, a7);
        return gf_square(a127);
    end function;

    -- AES S-Box = GF inverse followed by affine transform (0x63).
    function aes_sbox(x : byte_t) return byte_t is
        variable b : byte_t;
    begin
        b := gf_inverse(x);
        return b
            xor (b(6 downto 0) & b(7))
            xor (b(5 downto 0) & b(7 downto 6))
            xor (b(4 downto 0) & b(7 downto 5))
            xor (b(3 downto 0) & b(7 downto 4))
            xor x"63";
    end function;

    function aes_subword(w : word_t) return word_t is
    begin
        return aes_sbox(w(31 downto 24)) &
               aes_sbox(w(23 downto 16)) &
               aes_sbox(w(15 downto 8)) &
               aes_sbox(w(7 downto 0));
    end function;

    function aes_rotword(w : word_t) return word_t is
    begin
        return w(23 downto 0) & w(31 downto 24);
    end function;

    -- xtime: multiply by x modulo AES irreducible polynomial.
    function aes_xtime(x : byte_t) return byte_t is
    begin
        if x(7) = '1' then
            return (x(6 downto 0) & '0') xor x"1B";
        else
            return x(6 downto 0) & '0';
        end if;
    end function;

end package body aes128_keyexp_pkg;
