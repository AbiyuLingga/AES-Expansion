-- AES-128 on-the-fly Key Expansion (standalone, UNMASKED).
-- Each active clock emits one round key: K0 on START, then K1..K10.
-- Intended as a round-key source for an existing AES encryption core.
-- VHDL-93 RTL for Quartus / ModelSim.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.aes128_keyexp_pkg.all;

entity aes128_keyexp is
    port (
        clk         : in  std_logic;
        rst         : in  std_logic;  -- synchronous, active-high reset
        start       : in  std_logic;  -- accepted only when busy='0'
        key_in      : in  std_logic_vector(127 downto 0);
        round_key   : out std_logic_vector(127 downto 0);
        round_index : out std_logic_vector(3 downto 0); -- 0..10
        valid       : out std_logic;  -- high on each round_key update
        done        : out std_logic;  -- pulse when round 10 is output
        busy        : out std_logic
    );
end entity aes128_keyexp;

architecture rtl of aes128_keyexp is
    signal current_key : std_logic_vector(127 downto 0) := (others => '0');
    signal next_key    : std_logic_vector(127 downto 0);
    signal rcon        : byte_t := x"01";
    signal round_count : unsigned(3 downto 0) := (others => '0');
    signal busy_reg    : std_logic := '0';
begin
    -- Combinational step: from round key r to round key r+1.
    process (current_key, rcon)
        variable w0, w1, w2, w3 : word_t;
        variable t              : word_t;
        variable n0, n1, n2, n3 : word_t;
    begin
        w0 := current_key(127 downto 96);
        w1 := current_key(95 downto 64);
        w2 := current_key(63 downto 32);
        w3 := current_key(31 downto 0);

        t  := aes_subword(aes_rotword(w3)) xor (rcon & x"000000");
        n0 := w0 xor t;
        n1 := w1 xor n0;
        n2 := w2 xor n1;
        n3 := w3 xor n2;
        next_key <= n0 & n1 & n2 & n3;
    end process;

    process (clk)
    begin
        if rising_edge(clk) then
            -- valid and done are one-clock pulses (unless reassigned).
            valid <= '0';
            done  <= '0';

            if rst = '1' then
                current_key <= (others => '0');
                round_key   <= (others => '0');
                round_index <= (others => '0');
                rcon        <= x"01";
                round_count <= (others => '0');
                busy_reg    <= '0';
                valid       <= '0';
                done        <= '0';

            elsif (start = '1') and (busy_reg = '0') then
                current_key <= key_in;
                round_key   <= key_in;       -- K0 = original AES key
                round_index <= (others => '0');
                round_count <= (others => '0');
                rcon        <= x"01";
                busy_reg    <= '1';
                valid       <= '1';

            elsif busy_reg = '1' then
                current_key <= next_key;
                round_key   <= next_key;
                round_count <= round_count + 1;
                round_index <= std_logic_vector(round_count + 1);
                rcon        <= aes_xtime(rcon);
                valid       <= '1';

                -- current count=9 => tenth update, i.e. K10.
                if round_count = to_unsigned(9, round_count'length) then
                    done     <= '1';
                    busy_reg <= '0';
                end if;
            end if;
        end if;
    end process;

    busy <= busy_reg;
end architecture rtl;
