create_clock -name CLOCK_50 -period 20.000 [get_ports CLOCK_50]
# Board switches/buttons and visual outputs are asynchronous user I/O.
