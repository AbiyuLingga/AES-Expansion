-- Self-checking testbench for aes128_keyexp.
-- Test 1: FIPS 197 Appendix A.1, key = 2B7E...4F3C.
-- Test 2: well-known AES-128 key = 000102...0F.
-- VHDL-93 compatible testbench.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.aes128_keyexp_pkg.all;
use std.textio.all;

entity tb_aes128_keyexp is
end entity;

architecture sim of tb_aes128_keyexp is
    constant CLOCK_PERIOD : time := 10 ns;
    type keys_t is array (0 to 10) of std_logic_vector(127 downto 0);

    constant EXPECTED_1 : keys_t := (
         0 => x"2B7E151628AED2A6ABF7158809CF4F3C",
         1 => x"A0FAFE1788542CB123A339392A6C7605",
         2 => x"F2C295F27A96B9435935807A7359F67F",
         3 => x"3D80477D4716FE3E1E237E446D7A883B",
         4 => x"EF44A541A8525B7FB671253BDB0BAD00",
         5 => x"D4D1C6F87C839D87CAF2B8BC11F915BC",
         6 => x"6D88A37A110B3EFDDBF98641CA0093FD",
         7 => x"4E54F70E5F5FC9F384A64FB24EA6DC4F",
         8 => x"EAD27321B58DBAD2312BF5607F8D292F",
         9 => x"AC7766F319FADC2128D12941575C006E",
        10 => x"D014F9A8C9EE2589E13F0CC8B6630CA6"
    );

    constant EXPECTED_2 : keys_t := (
         0 => x"000102030405060708090A0B0C0D0E0F",
         1 => x"D6AA74FDD2AF72FADAA678F1D6AB76FE",
         2 => x"B692CF0B643DBDF1BE9BC5006830B3FE",
         3 => x"B6FF744ED2C2C9BF6C590CBF0469BF41",
         4 => x"47F7F7BC95353E03F96C32BCFD058DFD",
         5 => x"3CAAA3E8A99F9DEB50F3AF57ADF622AA",
         6 => x"5E390F7DF7A69296A7553DC10AA31F6B",
         7 => x"14F9701AE35FE28C440ADF4D4EA9C026",
         8 => x"47438735A41C65B9E016BAF4AEBF7AD2",
         9 => x"549932D1F08557681093ED9CBE2C974E",
        10 => x"13111D7FE3944A17F307A78B4D2B30C5"
    );

    -- NIST S-box reference table: testbench only, not synthesized.
    type sbox_reference_t is array (0 to 255) of byte_t;
    constant SBOX_REF : sbox_reference_t := (
        x"63", x"7C", x"77", x"7B", x"F2", x"6B", x"6F", x"C5", x"30", x"01", x"67", x"2B", x"FE", x"D7", x"AB", x"76",
        x"CA", x"82", x"C9", x"7D", x"FA", x"59", x"47", x"F0", x"AD", x"D4", x"A2", x"AF", x"9C", x"A4", x"72", x"C0",
        x"B7", x"FD", x"93", x"26", x"36", x"3F", x"F7", x"CC", x"34", x"A5", x"E5", x"F1", x"71", x"D8", x"31", x"15",
        x"04", x"C7", x"23", x"C3", x"18", x"96", x"05", x"9A", x"07", x"12", x"80", x"E2", x"EB", x"27", x"B2", x"75",
        x"09", x"83", x"2C", x"1A", x"1B", x"6E", x"5A", x"A0", x"52", x"3B", x"D6", x"B3", x"29", x"E3", x"2F", x"84",
        x"53", x"D1", x"00", x"ED", x"20", x"FC", x"B1", x"5B", x"6A", x"CB", x"BE", x"39", x"4A", x"4C", x"58", x"CF",
        x"D0", x"EF", x"AA", x"FB", x"43", x"4D", x"33", x"85", x"45", x"F9", x"02", x"7F", x"50", x"3C", x"9F", x"A8",
        x"51", x"A3", x"40", x"8F", x"92", x"9D", x"38", x"F5", x"BC", x"B6", x"DA", x"21", x"10", x"FF", x"F3", x"D2",
        x"CD", x"0C", x"13", x"EC", x"5F", x"97", x"44", x"17", x"C4", x"A7", x"7E", x"3D", x"64", x"5D", x"19", x"73",
        x"60", x"81", x"4F", x"DC", x"22", x"2A", x"90", x"88", x"46", x"EE", x"B8", x"14", x"DE", x"5E", x"0B", x"DB",
        x"E0", x"32", x"3A", x"0A", x"49", x"06", x"24", x"5C", x"C2", x"D3", x"AC", x"62", x"91", x"95", x"E4", x"79",
        x"E7", x"C8", x"37", x"6D", x"8D", x"D5", x"4E", x"A9", x"6C", x"56", x"F4", x"EA", x"65", x"7A", x"AE", x"08",
        x"BA", x"78", x"25", x"2E", x"1C", x"A6", x"B4", x"C6", x"E8", x"DD", x"74", x"1F", x"4B", x"BD", x"8B", x"8A",
        x"70", x"3E", x"B5", x"66", x"48", x"03", x"F6", x"0E", x"61", x"35", x"57", x"B9", x"86", x"C1", x"1D", x"9E",
        x"E1", x"F8", x"98", x"11", x"69", x"D9", x"8E", x"94", x"9B", x"1E", x"87", x"E9", x"CE", x"55", x"28", x"DF",
        x"8C", x"A1", x"89", x"0D", x"BF", x"E6", x"42", x"68", x"41", x"99", x"2D", x"0F", x"B0", x"54", x"BB", x"16"
    );

    signal clk         : std_logic := '0';
    signal rst         : std_logic := '1';
    signal start       : std_logic := '0';
    signal key_in      : std_logic_vector(127 downto 0) := (others => '0');
    signal round_key   : std_logic_vector(127 downto 0);
    signal round_index : std_logic_vector(3 downto 0);
    signal valid       : std_logic;
    signal done        : std_logic;
    signal busy        : std_logic;
    signal finished : boolean := false;
    function hex_string(v : std_logic_vector(127 downto 0)) return string is
        constant digits : string := "0123456789ABCDEF";
        variable result : string(1 to 32);
    begin
        for i in 0 to 31 loop
            result(i+1) := digits(to_integer(unsigned(v(127-4*i downto 124-4*i)))+1);
        end loop;
        return result;
    end function;
begin
    clk <= not clk after CLOCK_PERIOD / 2 when not finished else '0';

    dut : entity work.aes128_keyexp
        port map (
            clk         => clk,
            rst         => rst,
            start       => start,
            key_in      => key_in,
            round_key   => round_key,
            round_index => round_index,
            valid       => valid,
            done        => done,
            busy        => busy
        );

    stimulus : process
        variable expected : keys_t;
        file exported : text open write_mode is "roundkeys_sim.txt";
        variable line_out : line;
    begin
        for b in 0 to 255 loop
            assert aes_sbox(std_logic_vector(to_unsigned(b,8))) = SBOX_REF(b)
                report "S-box mismatch at decimal input " & integer'image(b) severity failure;
        end loop;
        report "PASS: all 256 S-box entries" severity note;
        -- Check representative S-Box values from FIPS 197.
        assert aes_sbox(x"00") = x"63" report "SBox(00) is wrong" severity failure;
        assert aes_sbox(x"01") = x"7C" report "SBox(01) is wrong" severity failure;
        assert aes_sbox(x"53") = x"ED" report "SBox(53) is wrong" severity failure;
        assert aes_sbox(x"CF") = x"8A" report "SBox(CF) is wrong" severity failure;
        assert aes_sbox(x"FF") = x"16" report "SBox(FF) is wrong" severity failure;

        wait until rising_edge(clk);
        wait until rising_edge(clk);
        wait for 1 ns;
        rst <= '0';

        for testcase in 1 to 2 loop
            if testcase = 1 then
                expected := EXPECTED_1;
            else
                expected := EXPECTED_2;
            end if;

            wait until falling_edge(clk);
            key_in <= expected(0);
            start  <= '1';

            -- Clock that accepts START emits K0.
            wait until rising_edge(clk);
            wait for 1 ns;
            assert valid = '1' report "K0 valid not asserted" severity failure;
            assert busy = '1' report "busy should be high after START" severity failure;
            assert done = '0' report "done asserted too early" severity failure;
            assert round_index = x"0" report "K0 round_index wrong" severity failure;
            assert round_key = expected(0)
                report "Test " & integer'image(testcase) & " K0 mismatch" severity failure;
            report "Test " & integer'image(testcase) & " round 0 OK";
            if testcase = 1 then
                write(line_out, hex_string(round_key)); writeline(exported, line_out);
            end if;
            start <= '0';

            -- Ten following edges emit K1..K10.
            for i in 1 to 10 loop
                wait until rising_edge(clk);
                wait for 1 ns;
                assert valid = '1'
                    report "valid missing at round " & integer'image(i) severity failure;
                assert unsigned(round_index) = to_unsigned(i, 4)
                    report "round_index wrong at round " & integer'image(i) severity failure;
                assert round_key = expected(i)
                    report "Test " & integer'image(testcase) &
                           " round " & integer'image(i) severity failure;
                if i = 10 then
                    assert done = '1' report "done missing on K10" severity failure;
                    assert busy = '0' report "busy not cleared on K10" severity failure;
                else
                    assert done = '0' report "done asserted before K10" severity failure;
                    assert busy = '1' report "busy dropped before K10" severity failure;
                end if;
                if testcase = 1 then
                    write(line_out, hex_string(round_key)); writeline(exported, line_out);
                end if;
                report "Test " & integer'image(testcase) &
                       " round " & integer'image(i) & " OK";
            end loop;

            -- Idle cycle; control pulses should clear.
            wait until rising_edge(clk);
            wait for 1 ns;
            assert valid = '0' report "valid did not clear" severity failure;
            assert done = '0' report "done did not clear" severity failure;
            assert busy = '0' report "busy should remain low" severity failure;
        end loop;

        report "SUCCESS: both AES-128 key schedules matched all 11 round keys" severity note;
        file_close(exported);
        finished <= true;
        wait;
    end process;
end architecture sim;
