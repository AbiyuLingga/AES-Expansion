if {![file isdirectory work]} {vlib work}
vcom -93 aes128_keyexp_pkg.vhd
vcom -93 aes128_keyexp.vhd
vcom -93 tb_aes128_keyexp.vhd
vsim work.tb_aes128_keyexp
add wave -r sim:/tb_aes128_keyexp/*
radix hexadecimal
run -all
wave zoom full
