# AES-128 Key Expansion standalone — DE1, without masking

Only Key Expansion is implemented in FPGA. No RFID, ESP32, UART, or hardware AES encryption. Two built-in public test keys are used; do not use real secret keys. Optional Python encrypts with a supplied key-schedule file.

## ModelSim
Open extracted folder. `do sim_keyexp.do` checks 256 S-box entries, two sets of 11 round keys, and emits actual first test keys to `roundkeys_sim.txt`. `quit -sim` then `do sim_board.do` tests board display. `roundkeys_reference.txt` is reference ONLY, not HDL output. Scripts use VHDL-93.

## Quartus
Use Quartus II 13.0 SP1 + Cyclone II support. Open `aes_de1_demo.qpf`; verify EP2C20F484C7 matches chip. Compile, check Fitter and TimeQuest (50 MHz, 20 ns target; timing not validated). If slack negative, redesign/pipeline or use correctly constrained slower clock before programming. Use board's onboard USB-Blaster (USB cable, JTAG, RUN switch) to load compiled .sof. Use its rated power supply if required.

Press KEY0 reset, release. SW7=0 for key 2B7E...4F3C, SW7=1 for 000102...0F. Press/release KEY1. LEDG0 stays on when key bank ready; LEDG1 busy pulse too brief to see. SW6:3 round 0–10, SW2:0 page 0–7, MSB first. Four seven-segment digits display 16 bits per page (invalid round shows 0000). Round 1 key A0FA FE17 8854 2CB1 23A3 3939 2A6C 7605. For software manually assemble 8 pages per round, 11 lines in order. Pin assignments based on DE1 user manual tables 4.1–4.5. Core has 4 algorithmic S-boxes in parallel, no lookup table. Board bank is not core; measure research area/timing separately.

## Optional Python (no third-party libraries)
`python aes_demo.py --self-test`
`python aes_demo.py --roundkeys roundkeys_sim.txt`
You can also use a manually transcribed board file or `roundkeys_reference.txt` as offline reference only. Never export production keys.

## Status
Python reference test passed in preparation. HDL compilation, simulation, timing, hardware test and actual side-channel measurements not performed in this environment. This is an unmasked reference, not a secure implementation.
